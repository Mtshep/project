﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDEmoGame
{
    class Game
    {
        //Constructor

        public Game()
        {
            Console.WriteLine("Creatig a game");
        }
    }
}
