﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoListProject
{
    class Program
    {
        enum MyMenu
        {
            AddTask = 1,
            RemoveTask,
            ViewLists,
            Exit
        }


        static void Menu()
        {
            Console.WriteLine("Enter 1 to add a task");
            Console.WriteLine("Enter 2 to remove a task");
            Console.WriteLine("Enter 3 to view list");
            Console.WriteLine("Enter 'e' to exit");
        }
        static void Main(string[] args)
        {
            bool Continue = true;

            List<string> mylist = new List<string>();

            Console.WriteLine("Welcome to the To do list program ");

            while (Continue)
            {
                Menu();

                int choice = int.Parse(Console.ReadLine());

                switch ((MyMenu)choice)
                {
                    case MyMenu.AddTask:
                        mylist = GetTask(mylist);
                        break;
                    case MyMenu.RemoveTask:
                        mylist = RemoveTask(mylist);
                        break;
                    case MyMenu.ViewLists:
                        ViewList(mylist);
                        break;
                    case MyMenu.Exit:
                        Continue = false;
                        break;
                    default:
                        break;
                }

            }

            Console.ReadLine();
        }

        static List<string> GetTask(List<string> mylist)
        {
            Console.WriteLine("Please enter the task you would like to add in the 'To Do List'");
            string task = Console.ReadLine();

            mylist.Add(task);
            Console.WriteLine("Task added to the list");

            return mylist;
        }

        static List<string> RemoveTask(List<string> mylist)
        {
            Console.WriteLine("Please remove the task you are done with in the 'To Do List'");
            string task = Console.ReadLine();

            mylist.Remove(task);
            Console.WriteLine("Task removed to the list");

            return mylist;
        }

        static void ViewList(List<string> mylist)
        {
            foreach (var item in mylist)
            {
                Console.WriteLine(item);
            }
        }

    }
}
