﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DEmoGame
{
    class State
    {
        Stack<State> states;
        protected bool end = false;
        public State(Stack<State> states)
        {
            this.states = states;     
        }

        public bool RequestEnd()
        {
            return this.end;
        }
        virtual public void Update()
        {

        }

    }

}

