﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DEmoGame
{
    class StateMenu : State
    {
        public StateMenu(Stack<State> states) : base(states)
        {
            Console.WriteLine("helloe State Menu");
        }

        override public void Update()
        {
            Console.WriteLine(Gui.MenuTi("Game State"));
            Console.WriteLine(Gui.MenuOp(0, "Create Character"));
            Console.WriteLine(Gui.MenuOp(-1, "Exit"));

            Console.WriteLine("Write a number");
            int num = int.Parse(Console.ReadLine());


            if (num < 0)
                this.end = true;
        }
    }
}
