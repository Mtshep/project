﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DEmoGame
{
    class StateGsame : State
    {
        public StateGsame(Stack<State> states) : base(states)
        {
            Console.WriteLine("This iss the Game State");

            
        }

        override public void Update()
        {
            Console.WriteLine("Write a number");
            int num = int.Parse(Console.ReadLine());

            Console.WriteLine(Gui.MenuTi("Game State"));
            Console.WriteLine(Gui.MenuOp(0, "Create Character"));
            Console.WriteLine(Gui.MenuOp(-1, "Exit")); 

            if (num < 0)
                this.end = true;
        }
    }
}
