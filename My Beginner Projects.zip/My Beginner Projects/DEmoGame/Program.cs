﻿using System;

namespace DEmoGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            Console.WriteLine(Gui.Title("WElocome Menu")); 
            game.Run();
        }
    }
}
