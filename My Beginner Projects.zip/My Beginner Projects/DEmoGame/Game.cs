﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DEmoGame
{
    class Game
    {
        
        private bool end;
       public bool End
       {
            get { return this.end; }
            set { this.end = value; }
       }

        private Stack<State> states;


       
        //private fuctions
        private void InitVarible()
        {
            this.End = false;
        }


        private void IniiState()
        {
            this.states = new Stack<State>();
           

            //Push the state
            this.states.Push(new StateMenu(this.states));
            this.states.Push(new StateGsame(this.states));
        }
        //Constructors and deconstructors
        public Game()
        {
          
            this.IniiState();
           
            this.InitVarible();

            Console.WriteLine("Hello World Game Developers");
        }

        public void Run()
        {
            while (this.states.Count > 0)
            {  
                
                    this.states.Peek().Update();

                    if(this.states.Peek().RequestEnd())
                        this.states.Pop();
                
            }

            Console.WriteLine("Ending game");
        }
    }
}
