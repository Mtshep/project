﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DEmoGame
{
    class Characters
    {
        public Characters()
        {

        }
    }
}
