﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DEmoGame
{
    class Gui
    {

        public static string Title(String tit)
        {
            tit = String.Format("++++{0}====", tit);

            return tit;
        }

        public static String MenuOp(int num, String tit)
        {
            tit = String.Format("* ({0}) {1}\n:", num, tit);

            return tit;
        }

        public static String MenuTi(String tit)
        {
            tit = String.Format("$$$$ {0}\n:", tit);

            return tit;
        }
    }

}
