﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashTempConverterProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wellcome! Please select 'c' for currncy converter and 't' for temperature converter");
            string choice1 = Console.ReadLine();

            if(choice1 == "c")
            {
                Console.WriteLine("You've selected currency converter");

                Console.WriteLine("Please select 'p' to convert to pound and 'e' to convert to euros");
                string choice2 = Console.ReadLine();

                if(choice2 == "p")
                {
                    Console.WriteLine("Please enter your money of pounds");
                    double money1 = double.Parse(Console.ReadLine());

                    double cal = money1 * 1.16;

                    Console.WriteLine("The money in euros is");
                    Console.WriteLine(cal);
                }
                else if(choice2 == "e")
                {
                    Console.WriteLine("Please enter your money of euro");
                    double money1 = double.Parse(Console.ReadLine());

                    double cal = money1 / 1.16;

                    Console.WriteLine("The money in pounds is");
                    Console.WriteLine(cal);
                }
            }
            else if(choice1 == "t")
            {
                Console.WriteLine("You've selected temperature converter");

                Console.WriteLine("Please select 'c' to convert to celsius and 'f' to convert to fahrenheit");
                string choice3 = Console.ReadLine();

                if(choice3 == "c")
                {
                    Console.WriteLine("Enter the temperature in celsisus");
                    double temp1 = double.Parse(Console.ReadLine());

                    double call = temp1 * 1.8 + 32;

                    Console.WriteLine("The temperture in Fahrenheit is");
                    Console.WriteLine(call);
                }
                else if(choice3 == "f")
                {
                    Console.WriteLine("Enter the temperature in Fahrenheit");
                    double temp1 = double.Parse(Console.ReadLine());

                    double call = temp1 - 32 * 0.56;

                    Console.WriteLine("The temperture in celsisus is");
                    Console.WriteLine(call);
                }
            }
            Console.ReadLine();
        }
    }
}
