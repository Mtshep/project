﻿using System;

namespace ShapeAreaCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What shape would you like to find the area of: 's' for a square, 'r' for a Rectangle, 't' for a Triangle or 'c' for circle");

            char select = char.Parse(Console.ReadLine());  

            if(select == 's')
            {
                Console.WriteLine("Enter your length of square");
                double num1 = Convert.ToDouble(Console.ReadLine());

                double cal = num1 * num1;
                Console.WriteLine("The result is: " + cal);
            }
            else if(select == 'r')
            {
                Console.WriteLine("Enter your height of rectangle");
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter your width of rectangle");
                double num2 = Convert.ToDouble(Console.ReadLine());

                double cal = num1 * num2;
                Console.WriteLine("The result is: " + cal);

            }
            else if (select == 't')
            {
                Console.WriteLine("Enter your height of triangle");
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter your width of triangle");
                double num2 = Convert.ToDouble(Console.ReadLine());

                double cal = 0.5 * num1 * num2;
                Console.WriteLine("The result is: " + cal);

            }
            else if (select == 'c')
            {
                Console.WriteLine("Enter your radius of a circle");
                double num1 = Convert.ToDouble(Console.ReadLine());

                double cal = 3.146 * num1;
                Console.WriteLine("The result is: " + cal);

            }
        }
    }
}
