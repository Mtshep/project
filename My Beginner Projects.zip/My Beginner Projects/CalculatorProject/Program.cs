﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the calculator ");
            Console.WriteLine();
            Console.WriteLine("Enter your first number");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your second number");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("What type of operation would you like to use?");
            char choice = char.Parse(Console.ReadLine());
            switch (choice)
            {
                case 'a':
                       Add(num,num2);
                    break;
                case 's':
                        Subtract(num, num2);
                    break;
                case 'm':
                    Multiply(num, num2);
                    break;
                case 'd':
                    Divide(num, num2);
                    break;
            }

            Console.WriteLine("Thank you for using the calculator program");

            Console.ReadKey();
        }


        static int Add(int num, int num2)
        {
            int cal = num + num2;
            Console.WriteLine("The result is " + cal);

            return cal;
        }

        static int Subtract(int num, int num2)
        {
            int cal = num - num2;
            Console.WriteLine("The result is " + cal);

            return cal;
        }

        static int Multiply(int num, int num2)
        {
            int cal = num * num2;
            Console.WriteLine("The result is " + cal);

            return cal;
        }

        static int Divide(int num, int num2)
        {
            int cal = num / num2;
            Console.WriteLine("The result is " + cal);

            return cal;
        }
    }
}
