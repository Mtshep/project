﻿using System;

namespace DiceGamee
{
    class Program
    {
        static void Main(string[] args)
        {
            int platerrandomnum;
            int enrmyrandomnum;

            int playerpoints = 0;
            int enrmypoint = 0;

            //Helps generate random varibles eg default
            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Press any key to roll the dice");

                Console.ReadKey();

                platerrandomnum = random.Next(1, 7);
                Console.WriteLine("You have rolled a " + platerrandomnum);

                Console.WriteLine("....");
                System.Threading.Thread.Sleep(1000);

                enrmyrandomnum = random.Next(1, 7);
                Console.WriteLine("Enemy AI has rolled a " + enrmyrandomnum);

                if(platerrandomnum > enrmyrandomnum)
                {
                    playerpoints++;
                    Console.WriteLine("Player wins this rounf" );
                }
                else if(enrmyrandomnum > platerrandomnum)
                {
                    enrmypoint++;
                    Console.WriteLine("Enermy wins this round");
                }
                else
                {
                    Console.WriteLine("No one wins thisround");
                }

                Console.WriteLine("The score is now :" + playerpoints + ":" + enrmypoint);
                Console.WriteLine();
            }

            if(playerpoints > enrmypoint)
            { 
                Console.WriteLine("You win"); 
            }
            else if(enrmypoint > playerpoints)
            {
                Console.WriteLine("Enermy won");
            }
            else
            {
                Console.WriteLine("No one won");
            }

            Console.ReadKey();
            
        }
    }
}
