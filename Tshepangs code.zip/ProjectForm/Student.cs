﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectForm
{
    class Student
    {
        private int studentid;
        private string studentname;
        private string studentsurname;
        private string gender;
        private string emailaddress;
        private DateTime dob;
        private string phonenumber;
        private string qualification;
        private double fees;
        private Double total;

        public Student(int studentid, string studentname, string studentsurname, string gender, string emailaddress, DateTime dob, string phonenumber, string qualification, double fees, double total)
        {
            this.studentid = studentid;
            this.studentname = studentname;
            this.studentsurname = studentsurname;
            this.gender = gender;
            this.emailaddress = emailaddress;
            this.dob = dob;
            this.phonenumber = phonenumber;
            this.qualification = qualification;
            this.fees = fees;
            this.total = total;
        }

        public int Studentid { get => studentid; set => studentid = value; }
        public string Studentname { get => studentname; set => studentname = value; }
        public string Studentsurname { get => studentsurname; set => studentsurname = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Emailaddress { get => emailaddress; set => emailaddress = value; }
        public DateTime Dob { get => dob; set => dob = value; }
        public string Phonenumber { get => phonenumber; set => phonenumber = value; }
        public string Qualification { get => qualification; set => qualification = value; }
        public double Fees { get => fees; set => fees = value; }
        public double Total { get => total; set => total = value; }
    }
}
