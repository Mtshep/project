﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Student> studentlist = new List<Student>();

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            studentlist.Add(new Student(int.Parse(txtID.Text), txtName.Text, txtSurname.Text, cmbGender.Text, txtEmail.Text, dateDOB.Value, txtNumber.Text, cmbQulify.Text, double.Parse(cmbFess.Text), double.Parse(txtCal.Text)));
            MessageBox.Show("Your Details have been added");

              
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            int index = dgv.SelectedRows[0].Index;
            studentlist[index].Studentid = int.Parse(txtID.Text);
            studentlist[index].Studentname = txtName.Text;
            studentlist[index].Studentsurname = txtSurname.Text;
            studentlist[index].Gender = cmbGender.Text;
            studentlist[index].Emailaddress = txtEmail.Text;
            studentlist[index].Dob = dateDOB.Value;
            studentlist[index].Phonenumber = txtNumber.Text;
            studentlist[index].Qualification = cmbQulify.Text;
            studentlist[index].Fees = double.Parse(cmbFess.Text);

            //I am trying to calculate the fees but it to not calculate on the form instead it brings the same fee entered 
            //My Calcultion methodes are at the bottom of this code.
            if(cmbGender.Text == "Male")
            {
               
                    studentlist[index].Total = price(double.Parse(cmbFess.Text));
                
            } 
            else if(cmbGender.Text == "Female")
            {
                studentlist[index].Total = priceF(double.Parse(cmbFess.Text));
            }
           
           

            dgv.DataSource = "";
            dgv.DataSource = studentlist;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            int index = dgv.SelectedRows[0].Index;
            studentlist.RemoveAt(index);

            dgv.DataSource = "";
            dgv.DataSource = studentlist;
        }

        private void BtnDisplay_Click(object sender, EventArgs e)
        {
            dgv.DataSource = "";
            dgv.DataSource = studentlist;
        }

        
        private void Button1_Click(object sender, EventArgs e)
        {
           
        }
        //This is my Calculations
        /*private static int CalculateAge(DateTime dateOfBirth)
        {
            int age = 0;
            age = DateTime.Now.Year - dateOfBirth.Year;
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
                age = age - 1;

            return age;
        }*/

        public static double price(double fees)
        {

            double cal = fees * 19 / 100;
            double total = fees - cal;

            return total;
        }

        private static double priceF(double fees)
        {

            double cal = fees * 30 / 100;
            double total = fees - cal;

            return total;
        }

    }
}
